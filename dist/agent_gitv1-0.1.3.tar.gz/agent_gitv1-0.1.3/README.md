# agent-gitv1

AI-powered Git CLI that uses Model Context Protocol (MCP) plus your configured LLM provider to automate commit workflows.

Supported providers:
- Google Gemini
- OpenAI
- Ollama (local or same-network)

## Features

- `agent config` to set provider and model
- Smart staging with auto-grouping (UI/backend/config/etc.)
- `agent commit` to generate commit messages from git diff
- Multiple commit suggestions (`--suggestions`)
- Repo-aware style learning from last ~20 commit subjects
- `agent explain` for change/intent/risk summaries
- Ollama model auto-detection on local network (`/24`, port `11434`)
- Loading/thinking spinner during long-running operations
- `agent push` to push to remote
- Fully LLM-driven `agent push` failure diagnosis from live git evidence
- Live command output streaming during push execution

## Prerequisites

- Python 3.10+
- `uvx` (`pip install uv`)
- Git
- Provider credentials (Gemini/OpenAI) or running Ollama server

## Installation

```bash
cd "d:\Vijay Projects\Agent_bhai"
pip install -e .
```

After install, use command:

```bash
agent --help
```

## Configuration

Start with:

```bash
agent config
```

Provider notes:
- Gemini: use `GEMINI_API_KEY` or save key in config
- OpenAI: use `OPENAI_API_KEY` or save key in config
- Ollama: can auto-detect servers like `http://192.168.1.35:11434`

## Commands

### `agent --help`
Shows all available commands and options.

### `agent config`
Configure provider and model.

When using Ollama, the tool can scan your local network and detect servers
like `http://192.168.1.35:11434`.

### `agent commit`
Smart-stage changes, generate repo-aware suggestions, choose messages, and commit.

Examples:

```bash
agent commit
agent commit --repo /path/to/repo
agent commit --suggestions 3
agent commit --no-smart-stage
agent commit --verbose
```

When smart staging is enabled (default), the CLI detects logical change groups and asks if it should create multiple commits.
During AI generation steps, a terminal loading spinner is shown.

### `agent explain`
Explain current changes with:
- what changed
- why it likely changed
- risk areas
- files impacted

Example:

```bash
agent explain
agent explain --repo /path/to/repo
```

`agent explain` also shows a loading spinner while the LLM is analyzing the diff.

### `agent push`
Push commits to remote.

Examples:

```bash
agent push
agent push --remote origin --branch main
```

`agent push` streams git output live in the terminal while running.

If push fails, the CLI now fetches live git evidence (`fetch`, local/remote logs,
ahead/behind counts, merge-base, branch tracking) and asks the LLM to diagnose
the exact root cause with recommended fix commands.
Diagnosis evidence commands also run live, so users can see each command and output.
Diagnosis output is plain text, PowerShell-command friendly, and auto-switches
to concise mode when evidence is clear.

## Environment Variables

- `GEMINI_API_KEY` (Gemini)
- `OPENAI_API_KEY` (OpenAI)

## Publish to PyPI

1. Bump version in `pyproject.toml` and `agent.py`
2. Build and validate:

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
```

3. Upload:

```bash
python -m twine upload dist/*
```

## Project Structure

```text
Agent_bhai/
|- agent.py
|- pyproject.toml
|- README.md
```

## License

MIT
